﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    public int startingHealth = 10;
    public int currentHealth;
    Animator anim;
    bool isDead;
    public AudioClip deathClip;
    public AudioClip attackClip;
    public AudioClip enemyLandingClip;
    public AudioClip enemyHurtClip;
    AudioSource enemyAudio;

    // Start is called before the first frame update
    void Start()
    {
        currentHealth = startingHealth;
        anim = GetComponent<Animator>();
        enemyAudio = GetComponent<AudioSource>();
    }

    public void TakeDamage(int damageTook)
    {
        if (isDead)
            return;
        currentHealth -= damageTook;
        if (currentHealth <= 0)
            Death();
        else
            enemyAudio.Play();
    }

    void Death()
    {
        isDead = true;

        anim.SetTrigger("Dead");

        enemyAudio.clip = deathClip;
        enemyAudio.Play();

        //Remove constraints, disable collider, run death animation, maybe change layer to background
    }

    // Update is called once per frame
    void Update()
    {
    }
}
