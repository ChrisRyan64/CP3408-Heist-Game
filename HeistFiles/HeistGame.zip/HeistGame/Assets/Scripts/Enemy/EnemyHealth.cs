﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    public int startingHealth = 100;
    public int currentHealth;
    Animator anim;
    bool isDead;
    //public AudioClip deathClip;
    //AudioSource enemyAudio;

    // Start is called before the first frame update
    void Start()
    {
        currentHealth = startingHealth;
        anim = GetComponent<Animator>();
        //enemyAudio = GetComponent<AudioSource>;
    }

    public void TakeDamage(int damageTook)
    {
        if (isDead)
            return;
        //enemyAudio.Play();
        currentHealth -= damageTook;
        if (currentHealth <= 0)
            Death();
    }

    void Death()
    {
        isDead = true;
        //enemyAudio.clip = deathClip;
        //enemyAudio.Play();

        //Remove constraints, disable collider, run death animation, maybe change layer to background
    }

    // Update is called once per frame
    void Update()
    {
        //Insert Death movements
    }
}
