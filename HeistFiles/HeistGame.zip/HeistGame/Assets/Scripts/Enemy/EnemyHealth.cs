﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    public int startingHealth = 10;
    public int currentHealth;
    Animator anim;
    bool isDead;
    public AudioClip deathClip;
    public AudioClip attackClip;
    public AudioClip enemyLandingClip;
    public AudioClip enemyHurtClip;
    AudioSource enemyAudio;
    private float deathTimer = .0f;

    // Start is called before the first frame update
    void Start()
    {
        currentHealth = startingHealth;
        anim = GetComponent<Animator>();
        enemyAudio = GetComponent<AudioSource>();
    }

    public void TakeDamage(int damageTook)
    {
        //enemy takes damage
            if (isDead)
                return;
            currentHealth -= damageTook;
            if (currentHealth <= 0)
            Invoke("Death", 1);
        else
                enemyAudio.Play();
    }

    void Death()
    {
        //enemy death
        isDead = true;

        anim.SetTrigger("Dead");

        enemyAudio.clip = deathClip;
        enemyAudio.Play();
        Invoke("Destroy", 2);
    }

    void Destroy()
    {
        //enemy destroy
        Destroy(gameObject);
    }
}
