﻿using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    //Movement variables
    public float speed = 6f;
    float facingLeftScale = -0.6f;
    float facingRightScale = 0.6f;
    public Text treasureText;
    private Rigidbody2D rb2d;
    private int treasure;
    //Jumping variables
    float distToGround;
    bool isGrounded;
    bool isJumping;
    bool jumpKeyHeld;
    Vector2 counterJumpForce;
    private float jumpForce;
    //Attack variables
    bool isAttacking = false;

    Vector2 movement;
    Animator anim;

    void Start()
    {
        anim = GetComponent<Animator>();
        rb2d = GetComponent<Rigidbody2D>();
        treasure = 0;
        jumpForce = CalculateJumpForce(Physics2D.gravity.magnitude, 5.0f);
    }
   
    void Update()
    {
        checkGrounded();
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            jumpKeyHeld = true;
            if (isGrounded)
            {
                isJumping = true;
                rb2d.AddForce(Vector2.up * jumpForce * rb2d.mass, ForceMode2D.Impulse);
            }
        }
        else
        {
            jumpKeyHeld = false;
        }
        if (Input.GetKeyDown(KeyCode.Space))
        {
            isAttacking = true;
        }
    }

    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        // Moves horizonatally
        transform.Translate(moveHorizontal * 15f * Time.deltaTime, 0f, 0f);
        Vector3 characterScale = transform.localScale;
        // Flips Player depending on direction
        if(moveHorizontal < 0)
        {
            characterScale.x = facingLeftScale;
        }
        if (moveHorizontal > 0)
        {
            characterScale.x = facingRightScale;
        }
        transform.localScale = characterScale;
        if (isAttacking)
        {
            isAttacking = false;
            Attacking(moveHorizontal, moveVertical);
        }
        else
        {
            Walking(moveHorizontal, moveVertical);
        }
        //Jumping
        if (isJumping)
        {
            //if jumping, apply their mass to bring them back down, i believe
            if (!jumpKeyHeld && Vector2.Dot(rb2d.velocity, Vector2.up) > 0)
            {
                rb2d.AddForce(counterJumpForce * rb2d.mass);
            }
        }
    }

    void Move(float moveHorizontal, float moveVertical)
    {
        movement.Set(moveHorizontal, moveVertical);
        movement = movement.normalized * speed * Time.deltaTime;
        rb2d.AddForce(movement);
    }

    void Walking(float moveHorizontal, float moveVertical)
    {
        bool walking = moveHorizontal != 0f;
        anim.SetBool("IsWalking", walking);
    }

    void Attacking(float moveHorizontal, float moveVertical)
    {
        bool attacking = moveHorizontal != 0f || moveVertical != 0f;
        anim.SetTrigger("IsAttacking");
    }

    void OnTriggerEnter2D(Collider2D other)
    // Removes treasure on touch and increases treasure count
    {
        if (other.gameObject.CompareTag("Treasure"))
        {
            other.gameObject.SetActive(false);
            treasure = treasure + 1;
            SetTreasureText();
        }
        else if (other.gameObject.CompareTag("Treasure2"))
        {
            other.gameObject.SetActive(false);
            treasure = treasure + 2;
            SetTreasureText();
        }

        else if (other.gameObject.CompareTag("Treasure3"))
        {
            other.gameObject.SetActive(false);
            treasure = treasure + 3;
            SetTreasureText();
        }
        if (treasure == 40)
        {
            //anim.SetTrigger("Move");
        }
    }

    void SetTreasureText()
    // Updates UI text for treasure count
    {
        treasureText.text = treasure.ToString();
    }

    //Jumping Methods

    public static float CalculateJumpForce(float gravityStrength, float jumpHeight){
        return Mathf.Sqrt(2 * gravityStrength * jumpHeight);
    }

    void checkGrounded()
    //super dodgy. Any vertical velocity stops Player from jumping, but they should only have that when jumping or falling
    {
        if (rb2d.velocity.y != 0)
        {
            isGrounded = false;
        }
        else
        {
            isGrounded = true;
        }
    }
}
