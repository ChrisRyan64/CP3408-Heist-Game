﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    private Rigidbody2D rb2d;
    Vector2 movement;
    Animator anim;
    GameObject player;
    CapsuleCollider2D capCol;
    PolygonCollider2D polyCol;
    MeshFilter meshFilter;
    MeshRenderer meshRender;
    //Player Tracking variables
    public bool playerDetected;
    public bool playerLost;
    public bool playerMeleeRange;
    // Patrol variables
    float startPosition;
    public float patrolDistance;
    float endPosition;
    // true = moving left, false = moving right
    bool patrolReturning;
    // Movement variables
    Vector3 characterScale;
    float walkHorizontalSpeed;
    float runHorizontalSpeed;



    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        rb2d = GetComponent<Rigidbody2D>();
        polyCol = GetComponent<PolygonCollider2D>();
        meshFilter = GetComponent<MeshFilter>();
        //Creates area to be shaded, signifying enemy vision area
        createVision();
        capCol = GetComponent<CapsuleCollider2D>();
        player = GameObject.FindGameObjectWithTag("Player");
        // Testing
        playerDetected = false;
        playerMeleeRange = false;
        playerLost = false;
        // Get starting x position
        startPosition = transform.position.x;
        // Set how far will be travelled
        patrolDistance = 15f;
        endPosition = startPosition - patrolDistance;
        // Set speed of movement
        walkHorizontalSpeed = 0.25f;
        runHorizontalSpeed = 1f;
        // Starts going left
        patrolReturning = false;
        // Currently always walking
        Walking();
    }

    private void FixedUpdate()
    {
        if (!playerDetected && !playerLost)
            //The default state of the Enemy patrolling and Player not in sight
        {
            // If Enemy has reached end position, flag to reverse direction
            if (transform.position.x <= endPosition)
            {
                patrolReturning = true;
            }
            // If Enemy has passed starting position, flag to reverse direction
            if (transform.position.x > startPosition)
            {
                patrolReturning = false;
            }
            // Move left if heading left
            if (!patrolReturning)
            {
                transform.Translate(-walkHorizontalSpeed * 15f * Time.deltaTime, 0f, 0f);
            }
            else
            // Move right if heading right
            {
                transform.Translate(walkHorizontalSpeed * 15f * Time.deltaTime, 0f, 0f);
            }

            Vector3 characterScale = transform.localScale;
            // Used instead of input as patrolReturning indicates direction
            if (!patrolReturning)
            {
                characterScale.x = -.7f;
            }
            if (patrolReturning)
            {
                characterScale.x = .7f;
            }
            transform.localScale = characterScale;
        }
        if (playerDetected && !playerMeleeRange)
            //Player spotted but too far away to attack. Closes in
        {
            if(transform.position.x < player.transform.position.x)
            {
                transform.Translate(runHorizontalSpeed * 15f * Time.deltaTime, 0f, 0f);
            }
            else{
                transform.Translate(-runHorizontalSpeed * 15f * Time.deltaTime, 0f, 0f);
            }
        }
        if(playerDetected && playerMeleeRange)
            //Close enough to attack the Player
        {
            //Attack Player
        }
        if(!playerDetected && playerLost)
            //Enemy returning to patrol zone
        {
            if(transform.position.x < endPosition)
            {
                transform.Translate(walkHorizontalSpeed * 15f * Time.deltaTime, 0f, 0f);
                //characterScale.x = 1;
            }
            else
            {
                transform.Translate(-walkHorizontalSpeed * 15f * Time.deltaTime, 0f, 0f);
                //characterScale.x = -1;
            }
            if(transform.position.x > endPosition && transform.position.x < startPosition)
                //If back within patrol zone, go back to patrolling
            {
                playerLost = false;
            }
            
        }
    }

    void Walking()
    {
        anim.SetBool("IsWalking", true);
    }

    //Physical Collision
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        { }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            
        }
    }
    
    //Non-Physical Collisions
    private void OnTriggerEnter2D(Collider2D collision)

    {
        if (collision.gameObject.CompareTag("Player"))
        {
            playerDetected = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            playerDetected = false;
            playerLost = true;
        }
    }

    void createVision()
        //Borrowed code. Triangulator converts polygon colliders into triangles for a mesh
    {
        int pointCount = 0;
        //Get each point of the poly collider
        pointCount = polyCol.GetTotalPointCount();      
        Mesh mesh = new Mesh();
        Vector2[] points = polyCol.points;
        Vector3[] vertices = new Vector3[pointCount];
        Vector2[] uv = new Vector2[pointCount];
        for (int j = 0; j < pointCount; j++)
        {
            Vector2 actual = points[j];
            //Finds the position of the points to be turned into triangles. Offset by the same y value as the collider
            vertices[j] = new Vector3(actual.x, actual.y + polyCol.offset.y, 0);
            uv[j] = actual;
        }
        Triangulator tr = new Triangulator(points);
        int[] triangles = tr.Triangulate();
        //Creates the mesh based on the points and triangles
        mesh.vertices = vertices;
        mesh.triangles = triangles;
        mesh.uv = uv;
        meshFilter.mesh = mesh;
    }
}
