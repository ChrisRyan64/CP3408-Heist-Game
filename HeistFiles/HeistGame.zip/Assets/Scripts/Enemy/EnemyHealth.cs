﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    public int startingHealth = 10;
    public int currentHealth;
    Animator anim;
    PolygonCollider2D polyCol;
    CapsuleCollider2D capCol;
    GameObject player;
    CapsuleCollider2D playerCol;
    //Is Enemy Dead
    public bool isDead;
    public AudioClip deathClip;
    public AudioClip attackClip;
    public AudioClip enemyLandingClip;
    public AudioClip enemyHurtClip;
    private EnemyController enemyController;
    AudioSource enemyAudio;

    void Start()
    {
        currentHealth = startingHealth;
        anim = GetComponent<Animator>();
        enemyAudio = GetComponent<AudioSource>();
        //Needed to alter on enemy death
        polyCol = GetComponent<PolygonCollider2D>();
        capCol = GetComponent<CapsuleCollider2D>();
        player = GameObject.FindGameObjectWithTag("Player");
        playerCol = player.GetComponent<CapsuleCollider2D>();
        enemyController = GetComponent<EnemyController>();
        isDead = false;
    }

    public void TakeDamage(int damageTook)
    {
        //enemy takes damage
            if (isDead)
                return;
            currentHealth -= damageTook;
            if (currentHealth <= 0)
            Invoke("Death", 1);
        else
            //Currently playing Death noise? Switch to Hurt noise first?
            enemyAudio.Play();
    }

    void Death()
    {
        //enemy death
        isDead = true;
        
        anim.SetTrigger("Dead");
        polyCol.enabled = false;
        Physics2D.IgnoreCollision(capCol, playerCol);;
        // Sets current clip to death noise
        enemyAudio.clip = deathClip;
        enemyAudio.Play();
        Invoke("Destroy", 2);
    }

    void Destroy()
    {
        //enemy destroy
        Destroy(gameObject);
    }
}
