﻿using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    public float speed = 6f;
    public Text treasureText;
    private Rigidbody2D rb2d;
    private int treasure;

    Vector2 movement;
    Animator anim;

    void Start()
    {
        anim = GetComponent<Animator>();
        rb2d = GetComponent<Rigidbody2D>();
        treasure = 0;
        // SetTreasureText();
    }

    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        // should we only get horizontal to prevent flying?
        float moveVertical = Input.GetAxis("Vertical");
        movement = new Vector2(moveHorizontal, moveVertical);
        rb2d.AddForce(movement * speed);

        Move(moveHorizontal, moveVertical);
        Walking(moveHorizontal, moveVertical);
    }

    void Move(float moveHorizontal, float moveVertical)
    {
        movement.Set(moveHorizontal, moveVertical);
        movement = movement.normalized * speed * Time.deltaTime;
        rb2d.MovePosition(movement);
    }

    void Walking(float moveHorizontal, float moveVertical)
    {
        bool walking = moveHorizontal != 0f || moveVertical != 0f;
        anim.SetBool("IsWalking", walking);
    }

//    void Running(float moveHorizontal, float moveVertical)
  //  {
    //    bool running = moveHorizontal != 0f || moveVertical != 0f;
      //  anim.SetBool("IsRunning", running);
    //}

//    void Attacking(float moveHorizontal, float moveVertical)
  //  {
    //    bool attacking = moveHorizontal != 0f || moveVertical != 0f;
      //  anim.SetBool("IsAttacking", attacking);
    //}

    void OnTriggerEnter2D(Collider2D other)
    // Removes treasure on touch and increases treasure count
    {
        if (other.gameObject.CompareTag("Treasure"))
        {
            other.gameObject.SetActive(false);
            treasure = treasure + 1;
            SetTreasureText();
        }
    }

    void SetTreasureText()
    // Updates UI text for treasure count
    {
        treasureText.text = "Treasure: " + treasure.ToString();
    }
}
